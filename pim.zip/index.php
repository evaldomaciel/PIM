<!DOCTYPE html>
<html>
    <?php
    include "./includes/config.php"; // Arquivo padrão de configuração do sistema que carregará variáveis de ambiente.
    include './includes/conecta.php';
    ?>
    <head>
        <meta charset="UTF-8">
        <title><?php echo $titulo ?></title>

        <script type="text/javascript">
            window.location = "./admin/index.php"
        </script>
    </head>
    <body>
    </body>
</html>
